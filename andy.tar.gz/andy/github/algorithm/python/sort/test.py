#!/usr/bin/python
# -*- coding: utf-8 -*-

list_ = {}

if list_:
    print "list not null"
