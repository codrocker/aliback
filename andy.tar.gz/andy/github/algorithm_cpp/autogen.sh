#! /bin/sh
set -x
aclocal
autoheader
autoconf
automake --foreign --add-missing --copy
