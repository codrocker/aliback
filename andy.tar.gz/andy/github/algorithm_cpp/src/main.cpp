#include<iostream>
#include"modules/Sort.h"
using namespace std;

int main(/*int argc, char** argv*/)
{
    cout << "请输入排序算法序号,回车结束\n快速排序：1\n选择排序：2" << endl;
    int16_t sort_type = 1;

    sort::Sort* sort_base_ptr = NULL;
    sort::QuickSort quick_sort;

    while(cin >> sort_type)
    {
        switch (sort_type){
        case 1:
            sort_base_ptr = &quick_sort;
            break;
        case 2:
            break;
        case 3:
            break;
        default:
            cout << "没有输入选项对应的算法，请核对后输入" << endl;
        }
        if (sort_base_ptr != NULL)
            cout << "排序前***********************" << endl;
            sort_base_ptr->display_elements();
            cout << "排序后-----------------------" << endl;
            sort_base_ptr->run();
            sort_base_ptr->display_elements();
        sort_base_ptr = NULL;
    }

    return 0;
}
