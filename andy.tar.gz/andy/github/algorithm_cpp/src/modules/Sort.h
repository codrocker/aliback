#ifndef ALGORITHNM_SRC_MODULES_SORT_H_
#define ALGORITHNM_SRC_MODULES_SORT_H_

#include<vector>
#include<string>
#include<iostream>
#include<stdint.h>

namespace sort{

class Sort
{
private:
    std::string name; 

protected:
    std::vector<int32_t> data;

public:
    Sort();
    Sort(std::vector<int32_t> in_data);
    void display_elements();
    virtual int run() = 0;
};

class QuickSort : public Sort
{
public:
    int run();
private:
    int32_t partition(int32_t data_start, int32_t data_end);
    int32_t quick_sort(int32_t start, int32_t end);
};

}

#endif // ALGORITHNM_SRC_MODULES_SORT_H_
