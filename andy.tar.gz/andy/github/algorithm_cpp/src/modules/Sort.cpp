#include"Sort.h"

using namespace std;

namespace sort{

Sort::Sort()
{
    int32_t data_array[10] = {4, 2, 3, 2, 6, 9, -1, -9, 3, 5};
    vector<int32_t> tmp(data_array, data_array + 10);
//    vector<int32_t> tmp;
//    tmp.push_back(4);
//    tmp.push_back(2);
//    tmp.push_back(3);
//    tmp.push_back(2);
//    tmp.push_back(6);
//    tmp.push_back(9);
//    tmp.push_back(-1);
//    tmp.push_back(-9);
//    tmp.push_back(3);
//    tmp.push_back(5);
    this->data = tmp;
    return;
}

void Sort::display_elements()
{
    for (vector<int>::iterator iter = this->data.begin(); iter != this->data.end(); iter++)
    {
        cout << this->data.max_size() << endl;
        std::cout << *iter << endl;
    }

    return;
}

int Sort::run()
{
    return 0;
}

int QuickSort::run ()
{
    int32_t data_size = int32_t(data.size());
    int32_t start = 0;
    int32_t end = data_size - 1;
    quick_sort(start, end);
    return 0;

}

int32_t QuickSort::partition(int32_t start, int32_t end)
{    
    int32_t tmp = data[start];

    while(end > start)
    {
        if (tmp > data[start + 1]){
            data[start] = data[start + 1];
            start++;
        }
        else{
            int32_t tmp_end;
            tmp_end = data[end];
            data[end] = data[start + 1];
            data[start + 1] = tmp_end;
            end--;
        }
    }

    data[start] = tmp;
    return start;
}

int32_t QuickSort::quick_sort(int32_t start, int32_t end)
{
    if (end <= start)
        return 0;
    int32_t mid = partition(start, end);

    quick_sort(start, mid - 1);
    quick_sort(mid + 1, end);

    return 0;
}

} // namespace
