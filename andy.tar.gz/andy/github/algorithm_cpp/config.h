/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* Name of package */
#define PACKAGE "algorithm"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "algorithm"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "algorithm 1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "algorithm"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0"

/* Version number of package */
#define VERSION "1.0"
