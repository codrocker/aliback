#!/bin/bash

vi ${1} 1>&- 2>&-<<EOF
    :${2}s/${3}/${4}/g
    :wq
EOF

fun(){ 
    local num=7;
    echo $num
}

fun
echo $num
