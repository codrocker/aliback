#!/bin/bash


echo "\"wang"
