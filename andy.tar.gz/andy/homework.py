#/usr/bin/python
# -*- coding:utf-8 -*-

import random



f = open("topics.txt", "a")
def generate_topics():
    global f
    for i in range(0, 100):
        f.write("\r\n\r\n\r\n\r\n每日20道\r\n\r\n\r\n\r\n")
        for j in range(0, 20):
            if random.randint(10, 90) % 2 == 0:
                add()
            else:
                sub()

def add():
    while(True):
      x = random.randint(10, 90)
      y = random.randint(10, 90)
      if x + y <= 100 and (x % 10 + y % 10 > 10):
          str = "%d    +    %d    =                    %d\r\n\r\n" % (x, y, x + y)
          f.write(str)
          break

def sub():
    while(True):
      x = random.randint(10, 99)
      y = random.randint(10, 99)
      if x - y > 0 and (x % 10 - y % 10 < 0):
          str = "%d    -    %d    =                    %d\r\n\r\n" % (x, y, x - y)
          f.write(str)
          break

generate_topics()
