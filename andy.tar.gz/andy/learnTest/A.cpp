#include <iostream>
#include "A.h"

using namespace std;

void fun()
{
    cout << var << endl;

    return;
}
