extern int var;
