#include <iostream>
#include<utility>
#include<map>
#include"head.h"

using namespace std;
struct Max{
    int max, left, right;
};

void find_max_sub_array(int data[]){
    Max max;
    int i = 0, j = 0,sum = 0;
    max.max = data[i];
    max.left = max.right = i;

    while(j < sizeof(data)){
        sum = sum + data[j];
        if (sum > max.max){
            max.max = sum;
            max.left = i;
            max.right = j;
        }

        if (sum <= 0){
            sum = 0;
            j++;
            i = j;
        }else{
            j++;
        }
    }

    cout << "max:" << max.max << "\nleft:" <<max.left << "\nright:" << max.right << endl;
}

struct Seqlist{
    int key;
    char jj;
};

void fun_test1()
{
}

int main()
{
    int data[] = {6, -9, 3, 4, -3 ,2, 1};
    find_max_sub_array(data);

    pair<int, int> p;

    p = make_pair(7, 8);
    
    cout << p.first << p.second << endl;

    map<int, int> m;
    m.insert(p);

    for (map<int, int>::iterator iter = m.begin(); iter != m.end(); iter++)
    {
        cout << iter->first << endl;
        cout << m.count(7) << endl;
    }

    struct Seqlist lst[10];
    cout << sizeof(lst) << endl;

    return 0;
}
