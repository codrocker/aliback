#include<iostream>

using namespace std;

void insert_sort(int data[10])
{
    if ((sizeof(data) / 4) < 2)
    {
        return;
    }

    int i = 1, tmp, j;

    for ( i = 1; i < 10; i++){
        j = i;
        tmp = data[i];

        while (j > 0){
            if (tmp >= data[j - 1]){
                data[j] = tmp;
                break;
                }else{
                    data[j] = data[j - 1];
                    j--;
                }
        }
        if(j == 0){
            data[0] = tmp;
        }
    }

    return;
}

int main()
{
    int data[] = {3,2,4, -7, 0, 9, -3,5,2,1};
    insert_sort(data);
    int i;
    for(i = 0; i < (sizeof(data) / 4); i++){
        cout << data[i] << endl;
    }
    return 0;
}
