#include <stdio.h>

typedef struct {
    int leftPos;
    int rightPos;
    int sum;
}SubArray;

//find max sub array in mid
SubArray findMaxMidArray(int a[],int left,int mid,int right) {
    SubArray maxMidArray;
    int sum,leftSum,rightSum;
    int i;

    //find max sub array from mid of rigth
    sum=0;
    leftSum=a[mid];
    maxMidArray.leftPos = mid;
    for(i=mid;i>=left;i--) {
        sum+=a[i];
        if(sum > leftSum) {
            leftSum = sum;
            maxMidArray.leftPos = i;
        }
    }

    //find max sub array from mid+1 of right
    sum=0;
    rightSum=a[mid+1];
    maxMidArray.rightPos = mid;
    for(i=mid+1;i<=right;i++) {
         sum+=a[i];
         if(sum>rightSum) {
             rightSum = sum;
             maxMidArray.rightPos = i;
         }
    }

    //cal max sub array's value
    maxMidArray.sum = leftSum + rightSum;

    return maxMidArray;

}


SubArray findMaxSubArray(int a[],int left,int right) {
    SubArray maxLeftArray,maxRightArray,maxMidArray;
    int mid;

    if(left == right) {
        SubArray maxSubArray;
        maxSubArray.leftPos = left;
        maxSubArray.rightPos = left;
        maxSubArray.sum = a[left];
        return maxSubArray;
    }

    mid = (left+right)/2;

    maxLeftArray = findMaxSubArray(a,left,mid);
    maxRightArray = findMaxSubArray(a,mid+1,right);
    maxMidArray = findMaxMidArray(a,left,mid,right);

    //compare which  array'sum is the best
    if(maxLeftArray.sum > maxMidArray.sum
            && maxLeftArray.sum > maxRightArray.sum)
        return maxLeftArray;
    else if(maxMidArray.sum > maxLeftArray.sum
            && maxMidArray.sum > maxRightArray.sum)
        return maxMidArray;
    else
        return maxRightArray;



}

int main() {
    int a[10] = {0,8,3,5,4,-6,-8,5,2,5};
    SubArray maxSubArray;
    maxSubArray = findMaxSubArray(a,0,9);
    printf("MaxSubArray:\n\t\tleftPos:%d,\t\trightPos:%d,\t\tsum:%d\n",
            maxSubArray.leftPos,maxSubArray.rightPos,maxSubArray.sum);
    return 0;
}
