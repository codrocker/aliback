extern int a;
