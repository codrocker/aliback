#ifndef _SORT_H_
#define _SORT_H_

#include <iostream>
class Sort{
public:
    void insertSort(int a[], int low, int high);
    void bubbleSort(int a[], int low, int high);
    int binarySearch(int a[], int low, int high, int value);
    void merge(int a[], int low, int high, int mid);
};

#endif
