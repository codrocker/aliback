#include "Sort.h"

void Sort::insertSort(int a[], int low, int high)
{
    int i = low + 1;
    int j = 0, tmp = 0;

    while(i <= high){
        j = i;

        while(j > low){
            if (a[j] < a[j - 1]){
                tmp = a[j - 1];
                a[j - 1] = a [j];
                a[j] = tmp;
                j--;
            }else{
                break;
            }
        }

        i++;
    }
}
void Sort::bubbleSort(int a[], int low, int high)
{
    int i = 0, tmp = 0;
    bool isExchange = false;

    while(low < high){
        i = low;
        isExchange = false;

        while (i < high){
            if (a[i] > a[i + 1]){
                tmp = a[i];
                a[i] = a[i + 1];
                a[i + 1] = tmp;
                isExchange = true;
            }

            i++;
        }

        if (!isExchange){
            break;
        }

        high--;
    }
}

int Sort::binarySearch(int a[], int low, int high, int value)
{
    int mid = 0;

    while(low <= high){
        mid = (low + high) / 2;
        if (a[mid] == value){
            return mid;
        }else if(a[mid] < value){
            low = mid + 1;
        }else{
            high = mid - 1;
        }
    }
    return -1;
}

void Sort::merge(int a[], int low, int high, int mid){
    int i = low, j = mid;
    int tmp[high - low + 1];
    int p = 0;

    while (i <= (mid - 1) || j <= high){
        if (i > (mid - 1)){
            tmp[p] = a[j];
            j++;
        }else if (j > high){
            tmp[p] = a[i];
            i++;
        }else{
            if (a[i] <= a[j]){
                tmp[p] = a[i];
                i++;
            }else{
                tmp[p] = a[j];
                j++;
            }
        }
        
        p++;
    }
    for(i = 0; i <= high; i++){
        std::cout << tmp[i] << std::endl;
    }
}
