#include <iostream>
#include <vector>
#include "Sort.h"

using namespace std;

int partition(int a[], int i, int j);
int partitionMy(int a[], int i, int j);
void quickSortMy(int a[], int low, int high);

int main(int argc, char** argv)
{   
    int array[] = {3,2,18886,2,2,2,2,8,1,0,42432,423451,240,242,32,3};

    //quickSortMy(array, 0, 15);
    Sort maopaoSort;
    //maopaoSort.bubbleSort(array, 0, 15);
    maopaoSort.insertSort(array, 0, 15);

    int i = 0;
    for (; i < 16; i++)
    {
        cout << array[i] << endl;
    }

    cout << "=============================" << endl;
    int value = 0;
    cin >> value;
    cout << maopaoSort.binarySearch(array, 0, 15, value) << endl;

    cout << "merge test====================" << endl;
    int arrayMerge[] = {1,2,3,4,5,3,4,5,6,7};
    maopaoSort.merge(arrayMerge, 0, 9, 5);

    return 0;
}

int partitionMy(int a[], int i, int j)
{
    int tmp = a[i];
    while (i < j)
    {
        while (i < j && tmp >= a[i+1])
        {
            a[i] = a[i+1];
            i++;
        }

        if (i < j){
            int tmp1 = a[i+1];
            a[i+1] = a[j];
            a[j] = tmp1;
            j--;
        }
    }
    
    a[i] = tmp;
    return i;
}
int partition(int a[], int i, int j)
{
    int tmp = a[i];

    while (i < j)
    {
        while (i < j && tmp <= a[j]){
            j--;
        }

        if (i < j){
            a[i] = a[j];
            i++;

            while(i < j && tmp >= a[i]){
                i++;
            }

            if (i < j)
            {
                a[j] = a[i];
                j--;
            }
        }
    }
    a[i] = tmp;
    return i;
}

void quickSortMy(int a[], int low, int high)
{
    if (low < high){
        int pos = partitionMy(a, low, high);

        if (low < (pos - 1)){
            quickSortMy(a, low, pos -1);
        }
        if ((pos + 1) < high){
            quickSortMy(a, pos + 1, high);
        }
    }
}
