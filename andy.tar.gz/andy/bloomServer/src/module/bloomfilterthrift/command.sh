#/bin/bash
thrift -r --gen cpp bloomfilter.thrift
