#include <iostream>
#include <stdint.h>
#include "thrift_filter/Serv.h"
#include <thrift/protocol/TBinaryProtocol.h>
#include <thrift/server/TSimpleServer.h>
#include <thrift/transport/TServerSocket.h>
#include <thrift/transport/TBufferTransports.h>

void testThrfitFun()
{
    return;
}
