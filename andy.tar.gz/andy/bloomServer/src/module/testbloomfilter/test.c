#include <stdio.h>

int main()
{
        printf("wangshuwei \n");

        return 0;
}
