#include "stdio.h"
#include<string>
#include<vector>
#include "math.h"
#include <stdlib.h>
#include <string.h>
using namespace std;
extern "C"{
string passworeencode(char * passwd, char *key );
string kaiXinPasswordEncode(string parameter);
int charCodeAt(char a);
string h(char *msg);
string bh(vector<int> & ar);
string en(char *p,char *key);
void sl(char *s,vector<int > &v,bool w);
int f(int s,int x,int y,int z);
int rotl(int x,int n);
string tohs(int str);
}
