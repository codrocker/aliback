#include <iostream>

using namespace std;

void quickSort(int i,int j);

int nums[20] = {0,2,6,4,888,888,888,-1,8,5,3,888,266,453,53452,53,0,3,888,234};
int main(int argc, char** argv)
{
    quickSort(0,19);
    int i;
    for (i = 0; i < 20; i++)
    {
        cout << nums[i] << endl;
    }
    return 0;
}

void quickSort(int i, int j)
{
    int i_0 = i;
    int j_0 = j;
    int tmp = nums[i];
    for (;i < j;)
    {
        if(nums[i + 1] < tmp)
        {
            nums[i] = nums[i+1];
            i++;
        }
        if (i < j)
        {

            if(nums[j] <= tmp)
            {
                nums[i] = nums[j];
                nums[j] = nums[i+1];
                i++;
            }
            else
            {
                j--;
            }
        }
    }
    nums[i] = tmp;
    if ( i > i_0)
    {
        i--;
    }
    if (j < j_0)
    {
        j++;
    }
    if (i_0 < i)
    {
        quickSort(i_0, i);
    }
    if (j < j_0)
    {
    quickSort(j,j_0);
    }
    return;
}
