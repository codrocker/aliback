#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
int nums[10] = {8,3,2,6,0,4,7,5,1,9};
int i;
int j;
for (i = 9; i > 0; i-- )
{
	int j;
	for (j = 0; j < i; j++)
	{
		if (nums[j] > nums[j+1])
		{
			int tmp;
			tmp = nums[j+1];
			nums[j+1] = nums[j];
			nums[j] = tmp;
		}
	}
}
for (i = 0;i < 10; i++)
{
	cout << nums[i] << endl;
}
}
