#include <iostream>

using namespace std;

int main()
{

}

long long fabonacci(unsigned n)
{
    int results[2] = {0, 1};

    if (n <= 1)
    {
        return results[n];
    }

    int i = 0;
    for ()
}
