#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
	int nums[10] = {4,3,2,1,9,8,7,5,6,0};
	int i;
	for (i = 2; i < 10 ; i++)
	{
		nums[0] = nums[i];
		int j;
		for (j = i - 1; nums[j] > nums[0]; j--)
		{
			nums[j+1] = nums[j];
		}
		nums[j+1] = nums[0];
	}

	for (i = 1; i < 10; i++)
	{
		cout << nums[i] << endl;
	}
}
