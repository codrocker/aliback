#include <stdio.h>
#include <iostream>
using namespace std;

#define SIZE 17

int main(int argc, char** argv)
{
	int nums[SIZE] = {3,9,7,0,4,5,6,2,8,1,23,88,22,19,66,29,88};
	int i;
	for (i = 1; i <= (SIZE) -1; i++)
	{
		int tmp = nums[i];
		int j;
		for (j = i - 1; tmp < nums[j] && j > -1; j--)
		{
			nums[j+1] = nums[j]; 
		}
		
		nums[j+1] = tmp;
	}
		for (i = 0; i < (SIZE) - 1 ; i++)
		{
			cout << nums[i] << endl;
		}

	return 0;
}
