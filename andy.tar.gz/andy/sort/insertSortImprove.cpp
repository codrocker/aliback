#include <stdio.h>
#include <iostream>
using namespace std;

#define SIZE 17

int main(int argc, char** argv)
{
	int nums[(SIZE) + 1] = {0,2324,888,9,2,3,7,4,828,8,6,5,77,70,1,27348,342};

	int i;
	for (i = 2; i <= (SIZE); i++)
	{
		nums[0] = nums[i];
		int j = i;
		while (nums[0] < nums[j-1])
		{
			nums[j] = nums[j-1];
			j--;
		}
		nums[j] = nums[0];
	}
	int index;
	for (index = 0; index <= (SIZE); index++)
	{
cout << nums[index] << endl;
}
	return 0;
}
