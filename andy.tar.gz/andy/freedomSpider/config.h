/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* Name of package */
#define PACKAGE "freedomSpider"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "723727871@qq.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "freedomSpider"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "freedomSpider 1.0.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "freedomspider"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0.0"

/* Version number of package */
#define VERSION "1.0.0"
