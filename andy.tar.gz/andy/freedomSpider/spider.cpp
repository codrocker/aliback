#include <iostream>
#include <stdio.h>

int main(int argc, char** argv)
{
	printf("I am a freedomSpider.\n");
	return 0;
}
