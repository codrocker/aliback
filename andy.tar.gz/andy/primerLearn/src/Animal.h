#include <iostream>
#include <string>

class Animal
{
public:
    Animal();
    explicit Animal(const int & legs);
    explicit Animal(const Animal & animal);
    Animal & operator = (const Animal & animal);
    bool eat();
    bool run();
public:
    int legs;
};

class DogClass:public Animal{
public: int Animal;
public:        int tmp;
    DogClass():tmp(4),Animal(8){
    }

};
