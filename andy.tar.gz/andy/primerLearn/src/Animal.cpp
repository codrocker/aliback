#include "Animal.h"

using namespace std;

Animal::Animal():legs(2)
{
}

Animal::Animal(const int &legs)
{
    this->legs = legs;
}

Animal::Animal(const Animal & animal)
{
    if (this == &animal)
    {
        return;
    }

    legs = animal.legs;
}

Animal & Animal::operator = (const Animal & animal)
{
    if (this == &animal)
    {
        return *this;
    }
    legs = animal.legs;
    return *this;
}

bool Animal::eat()
{
    cout << "Class Animal: I am eating." << endl;
}

extern int tmp = 7;

bool Animal::run()
{
    cout << "Class Animal" << legs << " legs running." << endl;
}
