#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include "Animal.h"
#include<ctime>

using namespace std;
int partitionMy(int a[], int i, int j);
void quickSortMy(int a[], int low, int high);

template <typename v>
void fun(v a){
    cout << "Hello." << endl;
    return;
}

template <class v> class Test{
public:
    void fun(v a);
};
template <class v> void Test<v>::fun(v a){
        cout << "world." << endl;
        return;
    }

int main(int argc, char** argv)
{   
    Test<int> test;
    test.fun(7);
    fun(1);
    Animal *cat = new Animal(2);
    cat->eat();
    cat->run();
    vector<Animal> animals(16, Animal(5));
    animals[0].run();
    
    DogClass dog1 = DogClass();
    dog1.run();

    int array[] = {3,2,18886,2,2,2,2,8,1,0,42432,423451,240,242,32,3};

    quickSortMy(array, 0, 15);

    int i = 0;
    for (; i < 16; i++)
    {
        cout << array[i] << endl;
    }

    // test float
    float price = 1E3F;
    std::cout << price;

    // test length of wchar_t
    char var_char_1 = '1';
    wchar_t var_char_2 = '1';
    std::cout << sizeof(var_char_1);
    std::cout << sizeof(var_char_2);

    // test suffix
    short var_int_1 = 7L;
    std::cout << sizeof(var_int_1);
    std::cout << var_int_1;



    return 0;
}

int partitionMy(int a[], int i, int j)
{
    int tmp = a[i];
    while (i < j)
    {
        while (i < j && tmp >= a[i+1])
        {
            a[i] = a[i+1];
            i++;
        }

        if (i < j){
            int tmp1 = a[i+1];
            a[i+1] = a[j];
            a[j] = tmp1;
            j--;
        }
    }
    
    a[i] = tmp;
    return i;
}
int partition(int a[], int i, int j)
{
    int tmp = a[i];

    while (i < j)
    {
        while (i < j && tmp <= a[j]){
            j--;
        }

        if (i < j){
            a[i] = a[j];
            i++;

            while(i < j && tmp >= a[i]){
                i++;
            }

            if (i < j)
            {
                a[j] = a[i];
                j--;
            }
        }
    }
    a[i] = tmp;
    return i;
}

void quickSortMy(int a[], int low, int high)
{
    if (low < high){
        int pos = partitionMy(a, low, high);

        if (low < (pos - 1)){
            quickSortMy(a, low, pos -1);
        }
        if ((pos + 1) < high){
            quickSortMy(a, pos + 1, high);
        }
    }
}
