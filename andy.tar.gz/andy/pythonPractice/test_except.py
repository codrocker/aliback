#!/usr/bin/python
#-*-coding:gbk-*-

from mylib.www import myName
import logging
import pdb
import os
import functools
from types import MethodType

def fun1():
    print "I am a fun1."
    try:
        fun2()
    except Exception, e:
        print "chu"

def fun2():
    print "I am a fun2."
    fun3()

def fun3():
    print "I am a fun3."
    raise Exception()

fun1()

