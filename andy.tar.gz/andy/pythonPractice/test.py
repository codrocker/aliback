#!/usr/bin/python
#-*-coding:gbk-*-

from mylib.www import myName
import logging
import pdb
import os
import functools
from types import MethodType

def Test():
    if '' == False:
        print "jjj"

Test()
