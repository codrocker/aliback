#!/usr/bin/python
#-*-coding:gbk-*-

'A test module'

import sys

__author__ = 'wsw'

print sys.argv[0]

def fun():
    if __name__ == '__main__':
        print 'Run by command line'
    else:
        print 'Run by other\'s ajust.'
