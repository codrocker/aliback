#!/usr/bin/python
#-*-coding:gbk-*-

'A test module'

import sys

__author__ = 'wsw'

myName = 'wangshuwei'

#print sys.argv[0]
_varTest = 'wangwenhui'
def _fun():
    if __name__ == '__main__':
        print 'Run by command line'
    else:
        print 'Run by other\'s ajust.'
