#encoding=utf-8
#-*- coding:utf-8-*-
import os
import sys
import urllib2
from lxml import etree
import json
import requests
import time
import pprint

user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'

def getWeather():
    # get 24 hours weather
    req1 = urllib2.Request('http://tianqi.2345.com/t/wea_hour_js/54511.js', headers={'User-Agent':user_agent})
    req2 = urllib2.Request('http://tianqi.2345.com/t/wea_hour_js/54511.js', headers={'User-Agent':user_agent})
    r1 = urllib2.urlopen(req1)
    r2 = urllib2.urlopen(req2)
    w1 = r1.read().strip().decode('gb2312', 'ignore')
    w2 = r2.read().strip().decode('gb2312', 'ignore')
    w_24 = []
    if w1 and w2:
        j1 = json.loads(w1[w1.find('['):w1.find(']')+1])
        j2 = json.loads(w2[w2.find('['):w2.find(']')+1])
        if j1 and j2:
            for j in j1: j['day'] = time.localtime().tm_mday; 
            for j in j2: j['day'] = time.localtime().tm_mday + 1;
            w_24 = j1[time.localtime().tm_hour:] + j2[:time.localtime().tm_hour+1]
    # get pm2.5 value
    req = urllib2.Request('http://waptianqi.2345.com/air-54511.htm', headers={'User-Agent':user_agent})
    r = urllib2.urlopen(req)
    req = etree.HTML(r.read().decode('gb2312', 'ignore'))
    pm_num = req.xpath("//div[@class='phrase']/span[@class='num']/text()")
    pm_str = req.xpath("//div[@class='phrase']/span[@class='status']/text()")
    # get weather message
    req = urllib2.Request('http://tianqi.2345.com/today-54511.htm', headers={'User-Agent':user_agent})
    r = urllib2.urlopen(req)
    req = etree.HTML(r.read().decode('gbk', 'ignore'))
    keys =  req.xpath("//div[@class='hour-detail today-detail']/div[@class='tbody']/div[@id='skInfo']/div[@class='filter']/ul[@class='parameter']/li/b/text()")
    values = req.xpath("//div[@class='hour-detail today-detail']/div[@class='tbody']/div[@id='skInfo']/div[@class='filter']/ul[@class='parameter']/li/i/text()")
    values[0] = '%s(%s)' %(pm_str[0], pm_num[0])
    result = ''
    for i, key in enumerate(keys):
        result += '%s%s\n' %(key, values[i])
    result += '-----24Сʱ����-----\n'
    for w in w_24:
        result += '%d��%s�� %s��C %s\n' %(w['day'], w['hour'], w['temp'], w['tq'])
    return result




if __name__ == '__main__':
    # set global coding to gb18030
    reload(sys)
    sys.setdefaultencoding('gb18030')

    print getWeather()

